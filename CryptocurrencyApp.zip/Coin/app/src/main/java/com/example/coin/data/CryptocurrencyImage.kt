package com.nurig.cryptocurrencylistapp.data

data class CryptocurrencyImage (
    val thumb: String,
    val small: String,
    val large: String,
)