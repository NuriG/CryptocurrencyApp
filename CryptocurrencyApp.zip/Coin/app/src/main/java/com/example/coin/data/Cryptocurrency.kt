package com.nurig.cryptocurrencylistapp.data

data class Cryptocurrency(val id: String)
